-- add_sizes_and_email.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- 1. Adds the sizes column to products (fixes upload error)
-- 2. Adds email column to profiles (fixes hidden emails in admin users page)
-- Safe to run multiple times.
-- ============================================================

-- ── 1. Add sizes column to products ──────────────────────────
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'products' and column_name = 'sizes'
  ) then
    alter table public.products add column sizes text[] default null;
  end if;
end $$;

-- ── 2. Add email column to profiles ──────────────────────────
do $$
begin
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'profiles' and column_name = 'email'
  ) then
    alter table public.profiles add column email text default null;
  end if;
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'profiles' and column_name = 'name'
  ) then
    alter table public.profiles add column name text default null;
  end if;
end $$;

-- ── 3. Backfill email + name into profiles from auth.users ───
update public.profiles p
set
  email = u.email,
  name  = u.raw_user_meta_data ->> 'name'
from auth.users u
where p.id = u.id
  and (p.email is null or p.email != u.email);

-- ── 4. Update the trigger to also save email on signup ───────
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, role, email, name)
  values (
    new.id,
    'user',
    new.email,
    new.raw_user_meta_data ->> 'name'
  )
  on conflict (id) do update
    set email = excluded.email,
        name  = excluded.name;
  return new;
end;
$$;

-- ── 5. Verify ─────────────────────────────────────────────────
select p.email, p.name, p.role
from public.profiles p
order by p.role desc;
