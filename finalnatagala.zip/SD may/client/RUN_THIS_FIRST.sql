-- ============================================================
-- RUN_THIS_FIRST.sql
-- Run this ONCE in Supabase → SQL Editor → New Query → Run
-- This sets up everything the app needs to work correctly.
-- Safe to run multiple times.
-- ============================================================

-- ── 1. PRODUCTS TABLE ────────────────────────────────────────
create table if not exists public.products (
  id          bigserial primary key,
  name        text        not null,
  category    text        not null default '',
  description text        not null default '',
  price       numeric     not null default 0,
  image       text        not null default '',
  stock       integer     not null default 0,
  sizes       text[]      default null,
  created_at  timestamptz not null default now()
);

-- Add sizes column if it doesn't exist (fixes upload error)
do $$ begin
  if not exists (select 1 from information_schema.columns
    where table_schema='public' and table_name='products' and column_name='sizes')
  then alter table public.products add column sizes text[] default null; end if;
end $$;

alter table public.products enable row level security;
drop policy if exists "Public read products"       on public.products;
drop policy if exists "Admin/staff insert products" on public.products;
drop policy if exists "Admin/staff update products" on public.products;
drop policy if exists "Admins manage products"      on public.products;

create policy "Public read products"
  on public.products for select using (true);

create policy "Admins manage products"
  on public.products for all
  using  (coalesce((auth.jwt()->'user_metadata'->>'role'),'') in ('admin','staff'))
  with check (coalesce((auth.jwt()->'user_metadata'->>'role'),'') in ('admin','staff'));

-- ── 2. PROFILES TABLE ────────────────────────────────────────
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  role       text        not null default 'user',
  email      text        default null,
  name       text        default null,
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;
drop policy if exists "Users read own profile"     on public.profiles;
drop policy if exists "Users update own profile"   on public.profiles;
drop policy if exists "Admins read all profiles"   on public.profiles;
drop policy if exists "Admins update all profiles" on public.profiles;

create policy "Users read own profile"
  on public.profiles for select using (auth.uid() = id);
create policy "Users update own profile"
  on public.profiles for update using (auth.uid() = id);
create policy "Admins read all profiles"
  on public.profiles for select
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'admin');
create policy "Admins update all profiles"
  on public.profiles for update
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'admin');

-- ── 3. ORDERS TABLE ──────────────────────────────────────────
create table if not exists public.orders (
  id               bigserial primary key,
  user_id          uuid        not null references auth.users(id) on delete cascade,
  status           text        not null default 'pending',
  total            numeric     not null default 0,
  shipping_name    text        default null,
  shipping_address text        default null,
  shipping_city    text        default null,
  shipping_phone   text        default null,
  payment_method   text        default 'cod',
  created_at       timestamptz not null default now()
);

-- Add shipping columns if missing
do $$ begin
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='orders' and column_name='shipping_name')
  then alter table public.orders add column shipping_name text default null; end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='orders' and column_name='shipping_address')
  then alter table public.orders add column shipping_address text default null; end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='orders' and column_name='shipping_city')
  then alter table public.orders add column shipping_city text default null; end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='orders' and column_name='shipping_phone')
  then alter table public.orders add column shipping_phone text default null; end if;
  if not exists (select 1 from information_schema.columns where table_schema='public' and table_name='orders' and column_name='payment_method')
  then alter table public.orders add column payment_method text default 'cod'; end if;
end $$;

alter table public.orders enable row level security;
drop policy if exists "Users read own orders"    on public.orders;
drop policy if exists "Users insert own orders"  on public.orders;
drop policy if exists "Users cancel own orders"  on public.orders;
drop policy if exists "Admins read all orders"   on public.orders;
drop policy if exists "Admins update all orders" on public.orders;
drop policy if exists "Staff read all orders"    on public.orders;

create policy "Users read own orders"
  on public.orders for select using (auth.uid() = user_id);
create policy "Users insert own orders"
  on public.orders for insert with check (auth.uid() = user_id);
create policy "Users cancel own orders"
  on public.orders for update
  using  (auth.uid() = user_id and status in ('pending','processing'))
  with check (auth.uid() = user_id and status = 'cancelled');
create policy "Admins read all orders"
  on public.orders for select
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'admin');
create policy "Admins update all orders"
  on public.orders for update
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'admin');
create policy "Staff read all orders"
  on public.orders for select
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'staff');

-- ── 4. ORDER ITEMS TABLE ─────────────────────────────────────
create table if not exists public.order_items (
  id         bigserial primary key,
  order_id   bigint  not null references public.orders(id) on delete cascade,
  product_id bigint  not null references public.products(id),
  qty        integer not null default 1,
  price      numeric not null default 0,
  size       text    default null
);

alter table public.order_items enable row level security;
drop policy if exists "Users read own order items"  on public.order_items;
drop policy if exists "Users insert own order items" on public.order_items;
drop policy if exists "Admins read all order items"  on public.order_items;
drop policy if exists "Staff read all order items"   on public.order_items;

create policy "Users read own order items"
  on public.order_items for select
  using (exists (select 1 from public.orders where orders.id=order_items.order_id and orders.user_id=auth.uid()));
create policy "Users insert own order items"
  on public.order_items for insert
  with check (exists (select 1 from public.orders where orders.id=order_items.order_id and orders.user_id=auth.uid()));
create policy "Admins read all order items"
  on public.order_items for select
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'admin');
create policy "Staff read all order items"
  on public.order_items for select
  using (coalesce((auth.jwt()->'user_metadata'->>'role'),'') = 'staff');

-- ── 5. AUTO-CREATE PROFILE ON SIGNUP ─────────────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, role, email, name)
  values (new.id, 'user', new.email, new.raw_user_meta_data->>'name')
  on conflict (id) do update
    set email = excluded.email, name = excluded.name;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ── 6. BACKFILL EXISTING USERS ───────────────────────────────
insert into public.profiles (id, role, email, name)
select id, 'user', email, raw_user_meta_data->>'name'
from auth.users
where id not in (select id from public.profiles)
on conflict (id) do nothing;

update public.profiles p
set email = u.email, name = u.raw_user_meta_data->>'name'
from auth.users u
where p.id = u.id and (p.email is null or p.email != u.email);

-- ── 7. SET ADMIN AND STAFF ROLES ─────────────────────────────
update public.profiles set role = 'admin'
where id = (select id from auth.users where email = 'jazzfersanchez@gmail.com' limit 1);

update public.profiles set role = 'staff'
where id = (select id from auth.users where email = 'venicecalla@gmail.com' limit 1);

-- ── 8. SYNC ROLES INTO JWT (user_metadata) ───────────────────
update auth.users
set raw_user_meta_data = raw_user_meta_data || jsonb_build_object('role', p.role)
from public.profiles p
where auth.users.id = p.id and p.role in ('admin','staff');

-- ── 9. VERIFY ────────────────────────────────────────────────
select u.email, p.role, u.raw_user_meta_data->>'role' as jwt_role
from auth.users u
left join public.profiles p on p.id = u.id
order by u.created_at desc;
