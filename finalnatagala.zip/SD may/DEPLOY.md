# How to Deploy SHOE-TA for Free

This guide deploys your project using:
- **GitHub** — stores your code
- **GitHub Pages** — hosts the frontend (client, admin, staff pages) for free
- **Render.com** — hosts the Node.js backend for free
- **Supabase** — already hosts your database for free

---

## Step 1 — Create a GitHub Account

Go to https://github.com and sign up for a free account.

---

## Step 2 — Install Git on your computer

Download from https://git-scm.com/download/win and install with default settings.

---

## Step 3 — Create a new GitHub repository

1. Go to https://github.com/new
2. Repository name: `shoeta` (or any name you want)
3. Set to **Public**
4. Click **Create repository**

---

## Step 4 — Upload your project to GitHub

Open a terminal (Command Prompt) in your project folder:

```
cd "C:\Users\jazzfer\Desktop\SD may"
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/shoeta.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

---

## Step 5 — Enable GitHub Pages (free frontend hosting)

1. Go to your repository on GitHub
2. Click **Settings** → **Pages** (left sidebar)
3. Under **Source**, select **Deploy from a branch**
4. Branch: `main`, Folder: `/ (root)`
5. Click **Save**

After 1-2 minutes your site will be live at:
```
https://YOUR_USERNAME.github.io/shoeta/client/index.html
```

---

## Step 6 — Deploy the Node server on Render (free backend)

1. Go to https://render.com and sign up with your GitHub account
2. Click **New** → **Web Service**
3. Connect your GitHub repo (`shoeta`)
4. Fill in these settings:
   - **Name:** `shoeta-api`
   - **Root Directory:** `server`
   - **Build Command:** `npm install`
   - **Start Command:** `node server.js`
   - **Instance Type:** Free
5. Click **Advanced** → **Add Environment Variable** and add:

| Key | Value |
|-----|-------|
| `SUPABASE_URL` | `https://qqiatpdjxoidyexojqto.supabase.co` |
| `SUPABASE_ANON_KEY` | `sb_publishable_NS-P25W9xc2NZCIEXJ-h9A_tZvXyPmY` |
| `SUPABASE_SERVICE_ROLE_KEY` | *(your service role key from Supabase Settings → API)* |
| `ADMIN_EMAILS` | `jazzfersanchez@gmail.com` |
| `PORT` | `10000` |

6. Click **Create Web Service**
7. Wait ~3 minutes for it to deploy
8. Your API URL will be something like: `https://shoeta-api.onrender.com`

---

## Step 7 — Update the API URL in your code

Once you have your Render URL, update these two files:

**`client/js/apiBase.js`** — change the last line:
```js
window.SHOETA_API_BASE = isLocal ? "http://localhost:5000" : "https://shoeta-api.onrender.com";
```

**`admin/js/apiBase.js`** — same change:
```js
const PROD_API_URL = "https://shoeta-api.onrender.com";
```

Then push the changes to GitHub:
```
git add .
git commit -m "Update API URL for production"
git push
```

GitHub Pages will automatically update within a minute.

---

## Step 8 — Update Supabase allowed URLs (important!)

Supabase blocks auth redirects from unknown URLs. Add your GitHub Pages URL:

1. Go to **Supabase → Authentication → URL Configuration**
2. Add to **Site URL**: `https://YOUR_USERNAME.github.io`
3. Add to **Redirect URLs**: `https://YOUR_USERNAME.github.io/shoeta/client/profile.html`
4. Click **Save**

---

## Your live URLs after deployment

| Page | URL |
|------|-----|
| Home | `https://YOUR_USERNAME.github.io/shoeta/client/index.html` |
| Shop | `https://YOUR_USERNAME.github.io/shoeta/client/shop.html` |
| Admin | `https://YOUR_USERNAME.github.io/shoeta/admin/dashboard.html` |
| Staff | `https://YOUR_USERNAME.github.io/shoeta/staff/dashboard.html` |
| API | `https://shoeta-api.onrender.com` |

---

## Important notes

- **Render free tier sleeps** after 15 minutes of inactivity. The first request after sleep takes ~30 seconds. This only affects the admin order panel — the shop, cart, and checkout work without the server.
- **GitHub Pages is always on** — no sleeping.
- **Supabase free tier** allows 500MB database and 1GB file storage — more than enough for a school project.

---

## Updating your site after changes

Every time you make changes, push to GitHub:
```
git add .
git commit -m "describe your change"
git push
```

GitHub Pages updates automatically. Render also redeploys automatically when you push.
