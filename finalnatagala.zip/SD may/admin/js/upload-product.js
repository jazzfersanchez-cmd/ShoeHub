// admin/js/upload-product.js
const SUPABASE_URL = "https://qqiatpdjxoidyexojqto.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_NS-P25W9xc2NZCIEXJ-h9A_tZvXyPmY";
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const allowedRoles = new Set(["admin"]);

async function getCurrentUserAndRole() {
  const { data, error } = await sb.auth.getUser();
  if (error || !data.user) return { user: null, role: null };
  const user = data.user;
  let role = user.user_metadata?.role || null;
  if (!role) {
    const { data: profile } = await sb.from("profiles").select("role").eq("id", user.id).maybeSingle();
    role = profile?.role || null;
  }
  return { user, role };
}

function setStatus(message, isError) {
  const wrap = document.getElementById("statusWrap");
  if (!wrap) return;
  wrap.innerHTML = message;
  wrap.className = isError
    ? "mt-4 rounded-2xl px-5 py-4 text-sm font-semibold bg-red-50 border border-red-200 text-red-700"
    : "mt-4 rounded-2xl px-5 py-4 text-sm font-semibold bg-emerald-50 border border-emerald-200 text-emerald-700";
  wrap.classList.remove("hidden");
}

function hideStatus() {
  const wrap = document.getElementById("statusWrap");
  if (wrap) wrap.classList.add("hidden");
}

// Upload a file to Supabase Storage and return the public URL
async function uploadFileToStorage(file) {
  const ext      = file.name.split(".").pop().toLowerCase();
  const filename = `product_${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const path     = `products/${filename}`;

  const { error: uploadErr } = await sb.storage
    .from("product-images")
    .upload(path, file, { contentType: file.type, upsert: false });

  if (uploadErr) throw new Error("Storage upload failed: " + uploadErr.message);

  const { data } = sb.storage.from("product-images").getPublicUrl(path);
  return data.publicUrl;
}

async function loadRecentProducts() {
  const container = document.getElementById("recentProducts");
  if (!container) return;
  const { data, error } = await sb.from("products")
    .select("id,name,category,price,image,stock")
    .order("id", { ascending: false })
    .limit(5);

  if (error || !data || !data.length) {
    container.innerHTML = `<p class="text-sm text-gray-400">No products yet.</p>`;
    return;
  }

  container.innerHTML = data.map(p => `
    <div class="flex items-center gap-4 bg-white border border-gray-200 rounded-2xl p-3">
      <img src="${p.image}" alt="${p.name}"
        class="w-14 h-14 rounded-xl object-cover border border-gray-100 shrink-0 bg-gray-100"
        onerror="this.style.display='none'">
      <div class="flex-1 min-w-0">
        <p class="font-black text-sm truncate">${p.name}</p>
        <p class="text-xs text-gray-400">${p.category} · PHP ${Number(p.price).toLocaleString()} · Stock: ${p.stock}</p>
      </div>
      <span class="text-xs text-gray-300 font-mono shrink-0">#${p.id}</span>
    </div>
  `).join("");
}

async function protectPage() {
  const { user, role } = await getCurrentUserAndRole();
  if (!user) {
    window.location.href = "../client/login.html";
    return false;
  }
  if (!allowedRoles.has(role)) {
    document.getElementById("uploadForm").style.display = "none";
    const denied = document.getElementById("accessDenied");
    const msg    = document.getElementById("accessMsg");
    if (denied) denied.classList.remove("hidden");
    if (msg) msg.textContent = `Your role is "${role || "user"}". Admin role required.`;
    return false;
  }
  return true;
}

async function uploadProduct(event) {
  event.preventDefault();
  hideStatus();

  const btn = document.getElementById("submitBtn");
  btn.textContent = "Uploading…";
  btn.disabled = true;

  const name        = document.getElementById("name").value.trim();
  const category    = document.getElementById("category").value.trim();
  const description = document.getElementById("description").value.trim();
  const price       = Number(document.getElementById("price").value);
  const stock       = Number(document.getElementById("stock").value);

  // Determine image source: file upload or URL
  const activeTab  = window.activeTab || "file";
  const fileInput  = document.getElementById("imageFile");
  const urlInput   = document.getElementById("imageUrl");
  const hiddenImg  = document.getElementById("image");
  let imageUrl     = "";

  try {
    if (activeTab === "file" && window.selectedFile) {
      // Upload file to Supabase Storage
      btn.textContent = "Uploading image…";
      setStatus("Uploading image to storage…", false);
      imageUrl = await uploadFileToStorage(window.selectedFile);
    } else if (activeTab === "url" && urlInput?.value.trim()) {
      imageUrl = urlInput.value.trim();
    } else if (hiddenImg?.value.trim()) {
      imageUrl = hiddenImg.value.trim();
    }

    if (!imageUrl) {
      setStatus("Please upload an image file or paste an image URL.", true);
      btn.textContent = "Upload Product";
      btn.disabled = false;
      return;
    }

    if (!name || !category || !description || isNaN(price) || isNaN(stock)) {
      setStatus("Please fill in all fields correctly.", true);
      btn.textContent = "Upload Product";
      btn.disabled = false;
      return;
    }

    btn.textContent = "Saving product…";
    setStatus("Saving product to database…", false);

    // Read selected sizes from the picker
    const sizesRaw = document.getElementById("sizes")?.value || "";
    let sizesArr = [];
    try { sizesArr = JSON.parse(sizesRaw); } catch { sizesArr = []; }

    if (!sizesArr.length) {
      document.getElementById("sizesError")?.classList.remove("hidden");
      setStatus("Please select at least one size.", true);
      btn.textContent = "Upload Product";
      btn.disabled = false;
      return;
    }

    // Try inserting with sizes first, fall back without if column doesn't exist
    let insertError = null;
    const { error: e1 } = await sb.from("products").insert([
      { name, category, description, price, image: imageUrl, stock, sizes: sizesArr }
    ]);
    insertError = e1;

    if (insertError && insertError.message && insertError.message.includes("sizes")) {
      // sizes column doesn't exist yet — insert without it
      const { error: e2 } = await sb.from("products").insert([
        { name, category, description, price, image: imageUrl, stock }
      ]);
      insertError = e2;
      if (!e2) {
        setStatus(`✓ "${name}" uploaded (sizes not saved — run add_sizes_and_email.sql in Supabase to enable sizes).`, false);
      }
    }

    const error = insertError;

    if (error) {
      setStatus(`Upload failed: ${error.message}`, true);
    } else {
      setStatus(`✓ "${name}" uploaded successfully!`, false);
      document.getElementById("uploadForm").reset();
      window.selectedFile = null;
      // Reset size picker to defaults
      if (typeof selectedSizes !== "undefined") {
        selectedSizes = new Set(["6","6.5","7","7.5","8","8.5","9","9.5","10","10.5","11","12"]);
        if (typeof renderSizePicker === "function") renderSizePicker();
      }
      // Reset file preview
      const filePreviewWrap = document.getElementById("filePreviewWrap");
      const dropLabel       = document.getElementById("dropLabel");
      if (filePreviewWrap) filePreviewWrap.classList.add("hidden");
      if (dropLabel)       dropLabel.classList.remove("hidden");
      // Reset URL preview
      const urlPreviewWrap = document.getElementById("urlPreviewWrap");
      if (urlPreviewWrap) urlPreviewWrap.classList.add("hidden");
      await loadRecentProducts();
    }
  } catch (err) {
    setStatus(`Error: ${err.message}`, true);
  }

  btn.textContent = "Upload Product";
  btn.disabled = false;
}

document.addEventListener("DOMContentLoaded", async () => {
  const ok = await protectPage();
  if (!ok) return;
  document.getElementById("uploadForm").addEventListener("submit", uploadProduct);
  await loadRecentProducts();
});
