const { createClient } = require("@supabase/supabase-js");

/**
 * Verifies Supabase JWT from Authorization: Bearer <access_token>
 * and checks user email against ADMIN_EMAILS (comma-separated in .env).
 */
async function requireAdmin(req, res, next) {
  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  const adminsRaw = process.env.ADMIN_EMAILS || "";

  if (!url || !anonKey) {
    return res.status(500).json({ error: "Server missing SUPABASE_URL or SUPABASE_ANON_KEY in .env" });
  }

  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  if (!token) {
    return res.status(401).json({ error: "Missing Authorization Bearer token. Log in on the site first." });
  }

  const supabase = createClient(url, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data?.user?.email) {
    return res.status(401).json({ error: error?.message || "Invalid or expired session. Log in again." });
  }

  const email = String(data.user.email).toLowerCase();
  const admins = adminsRaw
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);

  if (!admins.length) {
    return res.status(503).json({
      error: "ADMIN_EMAILS is not set on the server. Add your login email to server/.env",
    });
  }

  if (!admins.includes(email)) {
    return res.status(403).json({ error: "Not an admin account." });
  }

  req.adminEmail = email;
  req.adminUserId = data.user.id;
  next();
}

module.exports = { requireAdmin };
