const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const { requireAdmin } = require("../middleware/requireAdmin");

const router = express.Router();

const ALLOWED_STATUS = [
  "pending", "processing", "shipped", "on_the_way",
  "in_transit", "out_for_delivery", "delivered", "cancelled",
];

function serviceClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  return createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

// GET /api/admin/orders — list all orders
router.get("/orders", requireAdmin, async (_req, res) => {
  const sb = serviceClient();
  if (!sb) {
    return res.status(500).json({
      error: "Missing SUPABASE_SERVICE_ROLE_KEY in server/.env (needed to list all orders).",
    });
  }

  const selects = [
    "id,user_id,status,total,created_at,shipping_name,shipping_address,shipping_city,shipping_phone,payment_method,order_items(id,product_id,qty,price,size,products(name,image))",
    "id,user_id,status,total,created_at,order_items(id,product_id,qty,price,size,products(name,image))",
    "id,user_id,status,total,created_at,order_items(id,product_id,qty,price,size)",
    "id,user_id,status,total,created_at,order_items(id,product_id,qty,price)",
  ];

  let lastErr = null;
  for (const sel of selects) {
    const { data, error } = await sb.from("orders").select(sel).order("created_at", { ascending: false });
    if (!error) return res.json(data || []);
    lastErr = error;
  }

  return res.status(500).json({ error: lastErr?.message || "Failed to load orders" });
});

// PATCH /api/admin/orders/:id — update order status
router.patch("/orders/:id", requireAdmin, async (req, res) => {
  const sb = serviceClient();
  if (!sb) {
    return res.status(500).json({ error: "Missing SUPABASE_SERVICE_ROLE_KEY in server/.env" });
  }

  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Invalid order id" });

  const status = typeof req.body?.status === "string" ? req.body.status.trim().toLowerCase() : "";
  if (!ALLOWED_STATUS.includes(status)) {
    return res.status(400).json({ error: `Invalid status. Use one of: ${ALLOWED_STATUS.join(", ")}` });
  }

  const { data, error } = await sb.from("orders").update({ status }).eq("id", id).select("id,status").maybeSingle();
  if (error) return res.status(500).json({ error: error.message || "Update failed" });
  if (!data) return res.status(404).json({ error: "Order not found" });
  return res.json(data);
});

// GET /api/admin/analytics — summary stats
router.get("/analytics", requireAdmin, async (_req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Missing SUPABASE_SERVICE_ROLE_KEY in server/.env" });

  const [ordersRes, productsRes] = await Promise.all([
    sb.from("orders").select("id,status,total,created_at"),
    sb.from("products").select("id,stock"),
  ]);

  if (ordersRes.error) return res.status(500).json({ error: ordersRes.error.message });

  const orders = ordersRes.data || [];
  const products = productsRes.data || [];

  const totalRevenue = orders
    .filter((o) => o.status !== "cancelled")
    .reduce((sum, o) => sum + Number(o.total || 0), 0);

  const statusCounts = {};
  ALLOWED_STATUS.forEach((s) => { statusCounts[s] = 0; });
  orders.forEach((o) => {
    const s = String(o.status || "pending").toLowerCase();
    if (statusCounts[s] !== undefined) statusCounts[s]++;
  });

  const now = new Date();
  const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
  const revenueByDay = {};
  orders
    .filter((o) => o.status !== "cancelled" && new Date(o.created_at) >= thirtyDaysAgo)
    .forEach((o) => {
      const day = new Date(o.created_at).toISOString().slice(0, 10);
      revenueByDay[day] = (revenueByDay[day] || 0) + Number(o.total || 0);
    });

  const lowStockProducts = products.filter((p) => typeof p.stock === "number" && p.stock < 5);

  return res.json({
    total_orders: orders.length,
    total_revenue: totalRevenue,
    status_counts: statusCounts,
    revenue_by_day: revenueByDay,
    total_products: products.length,
    low_stock_count: lowStockProducts.length,
  });
});

// GET /api/admin/users — list all users
router.get("/users", requireAdmin, async (_req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Missing SUPABASE_SERVICE_ROLE_KEY in server/.env" });

  const { data: authData, error: authErr } = await sb.auth.admin.listUsers({ perPage: 1000 });
  if (authErr) return res.status(500).json({ error: authErr.message });

  const { data: profiles } = await sb.from("profiles").select("id,role");

  const users = (authData?.users || []).map((u) => {
    const profile = (profiles || []).find((p) => p.id === u.id);
    return {
      id: u.id,
      email: u.email,
      name: u.user_metadata?.name || "",
      role: profile?.role || u.user_metadata?.role || "user",
      created_at: u.created_at,
      last_sign_in_at: u.last_sign_in_at,
    };
  });

  return res.json(users);
});

// PATCH /api/admin/users/:id/role — update user role
router.patch("/users/:id/role", requireAdmin, async (req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Missing SUPABASE_SERVICE_ROLE_KEY in server/.env" });

  const allowedRoles = ["user", "staff", "admin"];
  const role = typeof req.body?.role === "string" ? req.body.role.trim().toLowerCase() : "";
  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ error: `Invalid role. Use one of: ${allowedRoles.join(", ")}` });
  }

  const { error: profileErr } = await sb.from("profiles").upsert({ id: req.params.id, role }, { onConflict: "id" });
  if (profileErr) return res.status(500).json({ error: profileErr.message });

  const { error: metaErr } = await sb.auth.admin.updateUserById(req.params.id, { user_metadata: { role } });
  if (metaErr) console.warn("Could not update user_metadata role:", metaErr.message);

  return res.json({ id: req.params.id, role });
});

module.exports = router;
