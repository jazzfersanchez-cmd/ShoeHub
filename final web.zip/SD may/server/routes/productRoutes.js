const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const router = express.Router();

function serviceClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// GET /api/products — list all products
router.get("/", async (_req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured (missing Supabase keys)." });

  let result = await sb.from("products").select("id,name,category,description,price,image,sizes,stock").order("id", { ascending: true });
  if (result.error) {
    // Retry without optional columns
    result = await sb.from("products").select("id,name,category,description,price,image,stock").order("id", { ascending: true });
  }
  if (result.error) return res.status(500).json({ error: result.error.message });
  return res.json(result.data || []);
});

// GET /api/products/:id — single product
router.get("/:id", async (req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Invalid product id." });

  let result = await sb.from("products").select("id,name,category,description,price,image,sizes,stock").eq("id", id).maybeSingle();
  if (result.error) {
    result = await sb.from("products").select("id,name,category,description,price,image,stock").eq("id", id).maybeSingle();
  }
  if (result.error) return res.status(500).json({ error: result.error.message });
  if (!result.data) return res.status(404).json({ error: "Product not found." });
  return res.json(result.data);
});

module.exports = router;