const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const router = express.Router();

/**
 * Payment routes — simulates a payment flow for the school project.
 * In a real app, integrate GCash, PayMaya, Stripe, etc. here.
 */

const PAYMENT_METHODS = ["cod", "gcash", "paymaya", "card"];

function serviceClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// POST /api/payments/checkout — process payment for an order
router.post("/checkout", async (req, res) => {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  // Verify user
  const userClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userErr } = await userClient.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Invalid or expired session." });

  const { order_id, payment_method, amount } = req.body || {};

  if (!order_id) return res.status(400).json({ error: "order_id is required." });
  if (!payment_method || !PAYMENT_METHODS.includes(String(payment_method).toLowerCase())) {
    return res.status(400).json({ error: `payment_method must be one of: ${PAYMENT_METHODS.join(", ")}` });
  }
  if (typeof amount !== "number" || amount <= 0) {
    return res.status(400).json({ error: "Valid amount (number > 0) is required." });
  }

  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  // Verify order belongs to user
  const { data: order, error: orderErr } = await sb.from("orders")
    .select("id,status,total").eq("id", Number(order_id)).eq("user_id", userData.user.id).maybeSingle();
  if (orderErr) return res.status(500).json({ error: orderErr.message });
  if (!order) return res.status(404).json({ error: "Order not found." });
  if (order.status === "cancelled") return res.status(400).json({ error: "Cannot pay for a cancelled order." });
  if (order.status === "delivered") return res.status(400).json({ error: "Order already delivered." });

  // Simulate payment processing (in production, call real payment gateway here)
  const method = String(payment_method).toLowerCase();
  let newStatus = "processing";

  // COD orders go straight to processing; others simulate instant payment confirmation
  if (method === "cod") {
    newStatus = "processing";
  } else {
    // Simulate successful online payment
    newStatus = "processing";
  }

  // Update order status
  const { data: updated, error: updateErr } = await sb.from("orders")
    .update({ status: newStatus }).eq("id", Number(order_id)).select("id,status,total").maybeSingle();
  if (updateErr) return res.status(500).json({ error: updateErr.message });

  // Generate a fake transaction reference
  const txRef = `SHOETA-${Date.now()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;

  return res.json({
    success: true,
    transaction_ref: txRef,
    order_id: updated.id,
    status: updated.status,
    amount_paid: amount,
    payment_method: method,
    message: method === "cod"
      ? "Order confirmed. Pay on delivery."
      : `Payment of PHP ${amount.toLocaleString()} received via ${method.toUpperCase()}. Order is now processing.`,
  });
});

// GET /api/payments/methods — list available payment methods
router.get("/methods", (_req, res) => {
  res.json([
    { id: "cod", label: "Cash on Delivery", icon: "💵" },
    { id: "gcash", label: "GCash", icon: "📱" },
    { id: "paymaya", label: "PayMaya", icon: "💳" },
    { id: "card", label: "Credit / Debit Card", icon: "🏦" },
  ]);
});

module.exports = router;