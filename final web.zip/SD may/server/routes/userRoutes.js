const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const { requireAdmin } = require("../middleware/requireAdmin");
const router = express.Router();

function serviceClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

// GET /api/users — list all users (admin only)
router.get("/", requireAdmin, async (_req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  // Try to get profiles table first (has role info)
  const { data: profiles, error: profileErr } = await sb.from("profiles").select("id,role").order("id");

  // Get auth users via admin API
  const { data: authData, error: authErr } = await sb.auth.admin.listUsers({ perPage: 1000 });
  if (authErr) return res.status(500).json({ error: authErr.message });

  const users = (authData?.users || []).map((u) => {
    const profile = (profiles || []).find((p) => p.id === u.id);
    return {
      id: u.id,
      email: u.email,
      name: u.user_metadata?.name || "",
      role: profile?.role || u.user_metadata?.role || "user",
      created_at: u.created_at,
      last_sign_in_at: u.last_sign_in_at,
    };
  });

  return res.json(users);
});

// GET /api/users/:id — get a single user (admin only)
router.get("/:id", requireAdmin, async (req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  const { data, error } = await sb.auth.admin.getUserById(req.params.id);
  if (error) return res.status(404).json({ error: error.message });

  const { data: profile } = await sb.from("profiles").select("role").eq("id", req.params.id).maybeSingle();

  return res.json({
    id: data.user.id,
    email: data.user.email,
    name: data.user.user_metadata?.name || "",
    role: profile?.role || data.user.user_metadata?.role || "user",
    created_at: data.user.created_at,
    last_sign_in_at: data.user.last_sign_in_at,
  });
});

// PATCH /api/users/:id/role — update user role (admin only)
router.patch("/:id/role", requireAdmin, async (req, res) => {
  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  const allowedRoles = ["user", "staff", "admin"];
  const role = typeof req.body?.role === "string" ? req.body.role.trim().toLowerCase() : "";
  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ error: `Invalid role. Use one of: ${allowedRoles.join(", ")}` });
  }

  // Update profiles table
  const { error: profileErr } = await sb.from("profiles").upsert({ id: req.params.id, role }, { onConflict: "id" });
  if (profileErr) return res.status(500).json({ error: profileErr.message });

  // Also update user_metadata
  const { error: metaErr } = await sb.auth.admin.updateUserById(req.params.id, { user_metadata: { role } });
  if (metaErr) console.warn("Could not update user_metadata role:", metaErr.message);

  return res.json({ id: req.params.id, role });
});

module.exports = router;