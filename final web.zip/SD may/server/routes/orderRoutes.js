const express = require("express");
const { createClient } = require("@supabase/supabase-js");
const router = express.Router();

const ALLOWED_STATUS = [
  "pending", "processing", "shipped", "on_the_way",
  "in_transit", "out_for_delivery", "delivered", "cancelled",
];

function serviceClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

function getUserFromToken(token) {
  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return null;
  return createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
}

// GET /api/orders — get orders for the authenticated user
router.get("/", async (req, res) => {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  const userClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userErr } = await userClient.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Invalid or expired session." });

  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  const selects = [
    "id,status,total,created_at,order_items(id,product_id,qty,price,size,products(name,image))",
    "id,status,total,created_at,order_items(id,product_id,qty,price,size)",
    "id,status,total,created_at,order_items(id,product_id,qty,price)",
  ];

  let lastErr = null;
  for (const sel of selects) {
    const { data, error } = await sb.from("orders").select(sel).eq("user_id", userData.user.id).order("created_at", { ascending: false });
    if (!error) return res.json(data || []);
    lastErr = error;
  }
  return res.status(500).json({ error: lastErr?.message || "Failed to load orders." });
});

// GET /api/orders/:id — get a single order (must belong to user)
router.get("/:id", async (req, res) => {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  const userClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userErr } = await userClient.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Invalid or expired session." });

  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Invalid order id." });

  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  const { data, error } = await sb.from("orders")
    .select("id,status,total,created_at,order_items(id,product_id,qty,price,size,products(name,image))")
    .eq("id", id)
    .eq("user_id", userData.user.id)
    .maybeSingle();

  if (error) return res.status(500).json({ error: error.message });
  if (!data) return res.status(404).json({ error: "Order not found." });
  return res.json(data);
});

// POST /api/orders — create a new order
router.post("/", async (req, res) => {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  const userClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userErr } = await userClient.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Invalid or expired session." });

  const { items, total } = req.body || {};
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: "items array is required." });
  if (typeof total !== "number" || total < 0) return res.status(400).json({ error: "Valid total is required." });

  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  // Validate product IDs exist
  const productIds = items.map((i) => Number(i.product_id)).filter(Number.isFinite);
  const { data: dbProducts, error: prodErr } = await sb.from("products").select("id,stock").in("id", productIds.length ? productIds : [-1]);
  if (prodErr) return res.status(500).json({ error: prodErr.message });

  const stockMap = new Map((dbProducts || []).map((p) => [p.id, p.stock]));

  // Create order
  const { data: order, error: orderErr } = await sb.from("orders")
    .insert([{ user_id: userData.user.id, status: "pending", total }])
    .select("id").single();
  if (orderErr) return res.status(500).json({ error: orderErr.message });

  // Insert order items
  const orderItems = items.map((item) => {
    const row = {
      order_id: order.id,
      product_id: Number(item.product_id),
      qty: Number(item.qty) || 1,
      price: Number(item.price) || 0,
    };
    if (item.size) row.size = String(item.size);
    return row;
  });

  let { error: itemsErr } = await sb.from("order_items").insert(orderItems);
  if (itemsErr) {
    // Retry without size column
    const withoutSize = orderItems.map(({ size, ...rest }) => rest);
    const retry = await sb.from("order_items").insert(withoutSize);
    if (retry.error) return res.status(500).json({ error: retry.error.message });
  }

  // Decrement stock for each product
  for (const item of items) {
    const pid = Number(item.product_id);
    const currentStock = stockMap.get(pid);
    if (typeof currentStock === "number") {
      const newStock = Math.max(0, currentStock - (Number(item.qty) || 1));
      await sb.from("products").update({ stock: newStock }).eq("id", pid);
    }
  }

  return res.status(201).json({ id: order.id, status: "pending", total });
});

// PATCH /api/orders/:id/cancel — cancel an order (user can only cancel their own pending orders)
router.patch("/:id/cancel", async (req, res) => {
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  const userClient = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: userData, error: userErr } = await userClient.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: "Invalid or expired session." });

  const id = Number(req.params.id);
  if (!Number.isFinite(id)) return res.status(400).json({ error: "Invalid order id." });

  const sb = serviceClient();
  if (!sb) return res.status(500).json({ error: "Server not configured." });

  // Verify order belongs to user and is cancellable
  const { data: existing, error: fetchErr } = await sb.from("orders")
    .select("id,status,user_id").eq("id", id).eq("user_id", userData.user.id).maybeSingle();
  if (fetchErr) return res.status(500).json({ error: fetchErr.message });
  if (!existing) return res.status(404).json({ error: "Order not found." });

  const cancellable = ["pending", "processing"];
  if (!cancellable.includes(existing.status)) {
    return res.status(400).json({ error: `Cannot cancel an order with status "${existing.status}".` });
  }

  const { data, error } = await sb.from("orders").update({ status: "cancelled" }).eq("id", id).select("id,status").maybeSingle();
  if (error) return res.status(500).json({ error: error.message });
  return res.json(data);
});

module.exports = router;