const express = require("express");
const router = express.Router();

/**
 * Auth routes — these are informational stubs.
 * The actual auth is handled client-side via Supabase JS SDK.
 * These endpoints exist for documentation/future server-side auth needs.
 */

// POST /api/auth/login — returns instructions (actual login is via Supabase client SDK)
router.post("/login", (_req, res) => {
  res.json({
    message: "Use the Supabase client SDK (signInWithPassword) for authentication.",
    docs: "https://supabase.com/docs/reference/javascript/auth-signinwithpassword",
  });
});

// POST /api/auth/register — returns instructions
router.post("/register", (_req, res) => {
  res.json({
    message: "Use the Supabase client SDK (signUp) for registration.",
    docs: "https://supabase.com/docs/reference/javascript/auth-signup",
  });
});

// GET /api/auth/me — verify a token and return user info
router.get("/me", async (req, res) => {
  const { createClient } = require("@supabase/supabase-js");
  const token = (req.headers.authorization || "").replace("Bearer ", "").trim();
  if (!token) return res.status(401).json({ error: "Missing Authorization token." });

  const url = process.env.SUPABASE_URL;
  const anonKey = process.env.SUPABASE_ANON_KEY;
  if (!url || !anonKey) return res.status(500).json({ error: "Server not configured." });

  const sb = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await sb.auth.getUser(token);
  if (error || !data?.user) return res.status(401).json({ error: "Invalid or expired token." });

  return res.json({
    id: data.user.id,
    email: data.user.email,
    name: data.user.user_metadata?.name || "",
    role: data.user.user_metadata?.role || "user",
  });
});

module.exports = router;