-- setup_storage.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- Creates a public storage bucket for product images
-- ============================================================

-- Create the bucket (public = anyone can view images)
insert into storage.buckets (id, name, public)
values ('product-images', 'product-images', true)
on conflict (id) do nothing;

-- Allow authenticated users (admin/staff) to upload images
create policy "Authenticated users can upload product images"
  on storage.objects for insert
  with check (
    bucket_id = 'product-images'
    and auth.uid() is not null
  );

-- Allow anyone to view/download product images (public catalog)
create policy "Public can view product images"
  on storage.objects for select
  using (bucket_id = 'product-images');

-- Allow authenticated users to delete their uploaded images
create policy "Authenticated users can delete product images"
  on storage.objects for delete
  using (
    bucket_id = 'product-images'
    and auth.uid() is not null
  );
