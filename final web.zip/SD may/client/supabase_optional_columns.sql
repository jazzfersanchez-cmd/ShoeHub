-- Run these in Supabase SQL Editor if your app should persist shoe size on each order line.
-- If `order_items` already has a `size` column, you can skip this.

alter table public.order_items
  add column if not exists size text;

comment on column public.order_items.size is 'US shoe size chosen at checkout (e.g. 9, 9.5).';
