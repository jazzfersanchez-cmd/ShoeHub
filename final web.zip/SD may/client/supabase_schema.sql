-- SHOE-TA Full Database Schema
-- Run this in Supabase SQL Editor to set up all tables from scratch.
-- Dashboard → SQL Editor → New Query → paste → Run

-- ============================================================
-- 1. PRODUCTS
-- ============================================================
create table if not exists public.products (
  id          bigserial primary key,
  name        text        not null,
  category    text        not null default '',
  description text        not null default '',
  price       numeric     not null default 0,
  image       text        not null default '',
  stock       integer     not null default 0,
  sizes       text[]      default null,
  created_at  timestamptz not null default now()
);

-- Allow anyone to read products (public catalog)
alter table public.products enable row level security;
create policy "Public read products"
  on public.products for select using (true);

-- Only authenticated users with admin/staff role can insert/update
create policy "Admin/staff insert products"
  on public.products for insert
  with check (
    auth.uid() is not null
  );

create policy "Admin/staff update products"
  on public.products for update
  using (auth.uid() is not null);

-- ============================================================
-- 2. PROFILES  (stores role: user | staff | admin)
-- ============================================================
create table if not exists public.profiles (
  id      uuid primary key references auth.users(id) on delete cascade,
  role    text not null default 'user',
  updated_at timestamptz default now()
);

alter table public.profiles enable row level security;

-- Users can read their own profile
create policy "Users read own profile"
  on public.profiles for select
  using (auth.uid() = id);

-- Users can update their own profile (role changes done server-side only)
create policy "Users update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Auto-create profile on signup
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ============================================================
-- 3. ORDERS
-- ============================================================
create table if not exists public.orders (
  id         bigserial primary key,
  user_id    uuid        not null references auth.users(id) on delete cascade,
  status     text        not null default 'pending',
  total      numeric     not null default 0,
  created_at timestamptz not null default now()
);

alter table public.orders enable row level security;

-- Users can read their own orders
create policy "Users read own orders"
  on public.orders for select
  using (auth.uid() = user_id);

-- Users can insert their own orders
create policy "Users insert own orders"
  on public.orders for insert
  with check (auth.uid() = user_id);

-- Users can update (cancel) their own pending/processing orders
create policy "Users cancel own orders"
  on public.orders for update
  using (auth.uid() = user_id and status in ('pending', 'processing'));

-- ============================================================
-- 4. ORDER ITEMS
-- ============================================================
create table if not exists public.order_items (
  id         bigserial primary key,
  order_id   bigint      not null references public.orders(id) on delete cascade,
  product_id bigint      not null references public.products(id),
  qty        integer     not null default 1,
  price      numeric     not null default 0,
  size       text        default null
);

alter table public.order_items enable row level security;

-- Users can read items for their own orders
create policy "Users read own order items"
  on public.order_items for select
  using (
    exists (
      select 1 from public.orders
      where orders.id = order_items.order_id
        and orders.user_id = auth.uid()
    )
  );

-- Users can insert items for their own orders
create policy "Users insert own order items"
  on public.order_items for insert
  with check (
    exists (
      select 1 from public.orders
      where orders.id = order_items.order_id
        and orders.user_id = auth.uid()
    )
  );

-- ============================================================
-- NOTES
-- ============================================================
-- After running this schema:
-- 1. Go to Supabase Dashboard → Authentication → Policies
--    and verify the policies were created.
-- 2. The service role key (used by the Node server) bypasses RLS,
--    so admin operations work without policy restrictions.
-- 3. To make a user an admin:
--    UPDATE public.profiles SET role = 'admin' WHERE id = '<user-uuid>';
--    OR use the Admin → Users page in the app once the server is running.
