-- fix_cancel_policy.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- Fixes the order cancellation RLS policy so users can cancel their own orders.
-- ============================================================

-- Drop the old conflicting policies
drop policy if exists "Users cancel own orders"  on public.orders;
drop policy if exists "Users update own orders"  on public.orders;

-- New policy: users can update their OWN orders that are pending or processing
-- using  = which rows can be targeted (must be theirs AND cancellable status)
-- with check = what the new row must look like (can only set status to 'cancelled')
create policy "Users cancel own orders"
  on public.orders
  for update
  using (
    auth.uid() = user_id
    and status in ('pending', 'processing')
  )
  with check (
    auth.uid() = user_id
    and status = 'cancelled'
  );

-- Verify policies on orders table
select policyname, cmd, qual, with_check
from pg_policies
where tablename = 'orders'
order by policyname;
