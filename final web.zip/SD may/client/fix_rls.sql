-- fix_rls.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- Adds admin AND staff RLS policies so both portals work WITHOUT the Node server.
-- Safe to run multiple times.
-- ============================================================

-- ── ORDERS: admins AND staff can read ALL orders ───────────────
drop policy if exists "Admins read all orders"       on public.orders;
drop policy if exists "Admins update all orders"     on public.orders;
drop policy if exists "Staff read all orders"        on public.orders;

create policy "Admins read all orders"
  on public.orders for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

create policy "Staff read all orders"
  on public.orders for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'staff'
  );

create policy "Admins update all orders"
  on public.orders for update
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

-- ── ORDER ITEMS: admins AND staff can read ALL order items ─────
drop policy if exists "Admins read all order items" on public.order_items;
drop policy if exists "Staff read all order items"  on public.order_items;

create policy "Admins read all order items"
  on public.order_items for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

create policy "Staff read all order items"
  on public.order_items for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'staff'
  );

-- ── PRODUCTS: admins AND staff can insert/update products ──────
drop policy if exists "Admins manage products" on public.products;

create policy "Admins manage products"
  on public.products for all
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') in ('admin', 'staff')
  )
  with check (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') in ('admin', 'staff')
  );

-- ── PROFILES: admins can read/update all profiles ─────────────
drop policy if exists "Admins read all profiles"   on public.profiles;
drop policy if exists "Admins update all profiles" on public.profiles;

create policy "Admins read all profiles"
  on public.profiles for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

create policy "Admins update all profiles"
  on public.profiles for update
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

-- ── Sync role into user_metadata so JWT contains it ───────────
-- Makes auth.jwt() -> 'user_metadata' ->> 'role' work correctly.
-- Run after setting roles in the profiles table.
-- IMPORTANT: After running this, log out and log back in to refresh your JWT.
update auth.users
set raw_user_meta_data = raw_user_meta_data || jsonb_build_object('role', p.role)
from public.profiles p
where auth.users.id = p.id
  and p.role in ('admin', 'staff');

-- ── Verify ────────────────────────────────────────────────────
select u.email, p.role,
       u.raw_user_meta_data ->> 'role' as jwt_role
from auth.users u
left join public.profiles p on p.id = u.id
order by u.created_at desc;
