-- fix_profiles.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- Safe to run multiple times (uses IF NOT EXISTS and ON CONFLICT DO NOTHING)
-- ============================================================

-- STEP 1: Create profiles table if it doesn't exist
-- ============================================================
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  role       text not null default 'user',
  updated_at timestamptz default now()
);

-- STEP 2: Enable Row Level Security
-- ============================================================
alter table public.profiles enable row level security;

-- STEP 3: Create RLS policies (drop first to avoid duplicates)
-- ============================================================
drop policy if exists "Users read own profile"      on public.profiles;
drop policy if exists "Users update own profile"    on public.profiles;
drop policy if exists "Admins read all profiles"    on public.profiles;
drop policy if exists "Admins update all profiles"  on public.profiles;

-- Any logged-in user can read their own profile
create policy "Users read own profile"
  on public.profiles for select
  using (auth.uid() = id);

-- Any logged-in user can update their own profile
create policy "Users update own profile"
  on public.profiles for update
  using (auth.uid() = id);

-- Admins can read ALL profiles (uses JWT metadata — no recursion)
create policy "Admins read all profiles"
  on public.profiles for select
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

-- Admins can update ALL profiles (uses JWT metadata — no recursion)
create policy "Admins update all profiles"
  on public.profiles for update
  using (
    coalesce((auth.jwt() -> 'user_metadata' ->> 'role'), '') = 'admin'
  );

-- STEP 4: Create the trigger function that auto-creates a profile on signup
-- ============================================================
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, role)
  values (new.id, 'user')
  on conflict (id) do nothing;
  return new;
end;
$$;

-- STEP 5: Attach the trigger to auth.users
-- ============================================================
drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute procedure public.handle_new_user();

-- STEP 6: Backfill — insert a profile row for every existing user who doesn't have one
-- ============================================================
insert into public.profiles (id, role)
select id, 'user'
from auth.users
where id not in (select id from public.profiles)
on conflict (id) do nothing;

-- STEP 7: Set jazzfersanchez@gmail.com as ADMIN
-- ============================================================
update public.profiles
set role = 'admin', updated_at = now()
where id = (
  select id from auth.users
  where email = 'jazzfersanchez@gmail.com'
  limit 1
);

-- STEP 8: Set venicecalla@gmail.com as STAFF
-- (Only works if she has already registered an account)
-- ============================================================
update public.profiles
set role = 'staff', updated_at = now()
where id = (
  select id from auth.users
  where email = 'venicecalla@gmail.com'
  limit 1
);

-- STEP 9: Verify — shows all users with their roles
-- ============================================================
select
  u.email,
  p.role,
  p.updated_at
from auth.users u
left join public.profiles p on p.id = u.id
order by u.created_at desc;
