-- add_shipping_columns.sql
-- Run this in Supabase → SQL Editor → New Query → Run
-- Adds shipping and payment columns to the orders table.
-- Safe to run multiple times (uses IF NOT EXISTS pattern via DO block).
-- ============================================================

do $$
begin
  -- Shipping name
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'orders' and column_name = 'shipping_name'
  ) then
    alter table public.orders add column shipping_name text default null;
  end if;

  -- Shipping address
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'orders' and column_name = 'shipping_address'
  ) then
    alter table public.orders add column shipping_address text default null;
  end if;

  -- Shipping city
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'orders' and column_name = 'shipping_city'
  ) then
    alter table public.orders add column shipping_city text default null;
  end if;

  -- Shipping phone
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'orders' and column_name = 'shipping_phone'
  ) then
    alter table public.orders add column shipping_phone text default null;
  end if;

  -- Payment method
  if not exists (
    select 1 from information_schema.columns
    where table_schema = 'public' and table_name = 'orders' and column_name = 'payment_method'
  ) then
    alter table public.orders add column payment_method text default 'cod';
  end if;
end $$;

-- Verify
select column_name, data_type, column_default
from information_schema.columns
where table_schema = 'public' and table_name = 'orders'
order by ordinal_position;
