/** Fallback catalog sizes (US). Supabase `products` rows can include `sizes` (text[] or json) to override. */
const DEFAULT_SHOE_SIZES = ["6", "6.5", "7", "7.5", "8", "8.5", "9", "9.5", "10", "10.5", "11", "12"];

const products = [
  {
    id: 1,
    name: "Air Sprint X",
    category: "Running",
    description: "Lightweight daily trainer with responsive foam.",
    price: 4595,
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff",
    sizes: DEFAULT_SHOE_SIZES,
  },
  {
    id: 2,
    name: "Court Elevate",
    category: "Basketball",
    description: "Mid-top support for explosive cuts and jumps.",
    price: 5295,
    image: "https://images.unsplash.com/photo-1600185365483-26d7a4cc7519",
    sizes: DEFAULT_SHOE_SIZES,
  },
  {
    id: 3,
    name: "Street Drift",
    category: "Lifestyle",
    description: "All-day comfort with a bold streetwear silhouette.",
    price: 3995,
    image: "https://images.unsplash.com/photo-1608231387042-66d1773070a5",
    sizes: DEFAULT_SHOE_SIZES,
  },
];