// client/js/supabaseClient.js
const SUPABASE_URL = "https://qqiatpdjxoidyexojqto.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_NS-P25W9xc2NZCIEXJ-h9A_tZvXyPmY";
window.sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);