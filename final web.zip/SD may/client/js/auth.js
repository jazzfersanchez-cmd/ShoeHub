(function () {
  function setAuthMessage(el, message, isError) {
    if (!el) return;
    el.textContent = message || "";
    el.className = "text-sm mt-2 " + (isError ? "text-red-600" : "text-green-600");
  }

  async function handleLogin(e) {
    e.preventDefault();
    const msg = document.getElementById("authMessage");
    const email = document.getElementById("loginEmail").value.trim();
    const password = document.getElementById("loginPassword").value;

    try {
      setAuthMessage(msg, "Signing in...", false);
      const { error } = await window.sb.auth.signInWithPassword({ email, password });
      if (error) throw error;
      setAuthMessage(msg, "Login successful. Redirecting...", false);
      // Redirect to ?next= page if present, otherwise profile
      const params = new URLSearchParams(window.location.search);
      const next = params.get("next");
      window.location.href = next ? decodeURIComponent(next) : "profile.html";
    } catch (err) {
      setAuthMessage(msg, err.message || "Login failed.", true);
    }
  }

  async function handleRegister(e) {
    e.preventDefault();
    const msg = document.getElementById("authMessage");
    const name = document.getElementById("registerName").value.trim();
    const email = document.getElementById("registerEmail").value.trim();
    const password = document.getElementById("registerPassword").value;

    try {
      setAuthMessage(msg, "Creating account...", false);
      const { error } = await window.sb.auth.signUp({
        email,
        password,
        options: { data: { name } },
      });
      if (error) throw error;
      setAuthMessage(msg, "Account created. Redirecting to login...", false);
      window.location.href = "login.html";
    } catch (err) {
      setAuthMessage(msg, err.message || "Registration failed.", true);
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const registerForm = document.getElementById("registerForm");
    if (loginForm) loginForm.addEventListener("submit", handleLogin);
    if (registerForm) registerForm.addEventListener("submit", handleRegister);
  });
})();