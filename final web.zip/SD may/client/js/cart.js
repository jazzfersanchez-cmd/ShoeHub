// client/js/cart.js
const CART_KEY = "shoeta_cart";
const catalogById = new Map();

function defaultSizes() {
  if (typeof DEFAULT_SHOE_SIZES !== "undefined" && Array.isArray(DEFAULT_SHOE_SIZES)) return DEFAULT_SHOE_SIZES;
  return ["7", "8", "9", "10", "11"];
}

function normalizeSizes(product) {
  if (!product) return defaultSizes();
  const s = product.sizes;
  if (Array.isArray(s) && s.length) return s.map(String);
  return defaultSizes();
}

function getCart() {
  try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; } catch { return []; }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function registerCatalog(list) {
  if (!Array.isArray(list)) return;
  list.forEach((item) => {
    if (!item || item.id === undefined || item.id === null) return;
    catalogById.set(String(item.id), {
      id: item.id,
      name: item.name,
      price: Number(item.price) || 0,
      sizes: normalizeSizes(item),
      stock: typeof item.stock === "number" ? item.stock : null,
    });
  });
}

function findProduct(productId) {
  const byCatalog = catalogById.get(String(productId));
  if (byCatalog) return byCatalog;
  if (typeof products === "undefined" || !Array.isArray(products)) return null;
  const found = products.find((p) => String(p.id) === String(productId));
  if (!found) return null;
  return { id: found.id, name: found.name, price: Number(found.price) || 0, sizes: normalizeSizes(found), stock: found.stock ?? null };
}

function addToCart(productId, size) {
  const product = findProduct(productId);
  if (!product) return;

  // Block if out of stock
  if (typeof product.stock === "number" && product.stock === 0) {
    showToast(`"${product.name}" is out of stock.`, "error");
    return;
  }

  const sizes  = product.sizes && product.sizes.length ? product.sizes : defaultSizes();
  const picked = size && sizes.includes(String(size)) ? String(size) : String(sizes[Math.floor(sizes.length / 2)] || sizes[0]);

  const cart     = getCart();
  const existing = cart.find((item) => String(item.id) === String(productId) && String(item.size || "") === picked);

  // Check stock against current cart qty
  const currentQty = existing ? existing.qty : 0;
  if (typeof product.stock === "number" && currentQty >= product.stock) {
    showToast(`Only ${product.stock} of "${product.name}" available. You already have ${currentQty} in your cart.`, "error");
    return;
  }

  if (existing) existing.qty += 1;
  else cart.push({ id: product.id, name: product.name, price: product.price, size: picked, qty: 1 });

  saveCart(cart);
  updateCartCount();
  showToast(`${product.name} (US ${picked}) added to cart ✓`);
}

// Toast notification — replaces alert()
function showToast(message, type = "success") {
  let toast = document.getElementById("shoeta-toast");
  if (!toast) {
    toast = document.createElement("div");
    toast.id = "shoeta-toast";
    toast.style.cssText = `
      position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);
      padding:12px 20px;border-radius:12px;font-size:0.85rem;font-weight:700;
      z-index:9999;opacity:0;transition:all 0.25s;max-width:90vw;text-align:center;
      box-shadow:0 4px 20px rgba(0,0,0,0.15);pointer-events:none;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.style.background = type === "error" ? "#fee2e2" : "#d1fae5";
  toast.style.color       = type === "error" ? "#991b1b" : "#065f46";
  toast.style.opacity     = "1";
  toast.style.transform   = "translateX(-50%) translateY(0)";
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => {
    toast.style.opacity   = "0";
    toast.style.transform = "translateX(-50%) translateY(20px)";
  }, 3000);
}

function updateCartCount() {
  const countEl = document.getElementById("cartCount");
  if (!countEl) return;
  countEl.textContent = String(getCart().reduce((sum, item) => sum + item.qty, 0));
}

function renderCartPage() {
  const container = document.getElementById("cartItems");
  const totalEl   = document.getElementById("cartTotal");
  if (!container || !totalEl) return;

  const cart = getCart();
  if (!cart.length) {
    container.innerHTML = `
      <div class="text-center py-10">
        <p class="text-4xl mb-3">🛒</p>
        <p class="font-bold text-lg">Your cart is empty</p>
        <a href="shop.html" class="mt-3 inline-block underline font-semibold text-sm">Browse the shop</a>
      </div>`;
    totalEl.textContent = "0";
    return;
  }

  container.innerHTML = cart.map((item, idx) => `
    <div class="flex items-center gap-4 py-4 border-b border-zinc-200 dark:border-zinc-800 last:border-0">
      <div class="flex-1 min-w-0">
        <p class="font-bold">${item.name}</p>
        <p class="text-sm text-zinc-500">Size US ${item.size || "—"}</p>
      </div>
      <div class="flex items-center gap-2">
        <button onclick="changeQty(${idx}, -1)" class="w-7 h-7 rounded-full border font-black text-sm flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800">−</button>
        <span class="font-bold w-6 text-center">${item.qty}</span>
        <button onclick="changeQty(${idx}, 1)"  class="w-7 h-7 rounded-full border font-black text-sm flex items-center justify-center hover:bg-zinc-100 dark:hover:bg-zinc-800">+</button>
      </div>
      <p class="font-black w-28 text-right">PHP ${(item.price * item.qty).toLocaleString()}</p>
      <button onclick="removeFromCart(${idx})" class="text-zinc-400 hover:text-red-500 transition-colors text-lg leading-none">✕</button>
    </div>
  `).join("");

  totalEl.textContent = cart.reduce((sum, item) => sum + item.price * item.qty, 0).toLocaleString();
}

function changeQty(idx, delta) {
  const cart = getCart();
  if (!cart[idx]) return;
  const newQty = cart[idx].qty + delta;
  if (newQty <= 0) { removeFromCart(idx); return; }

  // Check stock cap
  const prod = findProduct(cart[idx].id);
  if (delta > 0 && prod && typeof prod.stock === "number" && newQty > prod.stock) {
    showToast(`Only ${prod.stock} available for "${cart[idx].name}".`, "error");
    return;
  }

  cart[idx].qty = newQty;
  saveCart(cart);
  updateCartCount();
  renderCartPage();
}

function removeFromCart(idx) {
  const cart = getCart();
  cart.splice(idx, 1);
  saveCart(cart);
  updateCartCount();
  renderCartPage();
}

window.changeQty      = changeQty;
window.removeFromCart = removeFromCart;
window.showToast      = showToast;

if (typeof products !== "undefined" && Array.isArray(products)) {
  registerCatalog(products);
}

window.registerCatalog = registerCatalog;
window.defaultSizes    = defaultSizes;