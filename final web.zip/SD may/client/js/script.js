function toggleDark() {
  document.documentElement.classList.toggle("dark");
  const isDark = document.documentElement.classList.contains("dark");
  localStorage.setItem("shoeta_theme", isDark ? "dark" : "light");
}
function bootTheme() {
  const theme = localStorage.getItem("shoeta_theme");
  if (theme === "dark") document.documentElement.classList.add("dark");
  else document.documentElement.classList.remove("dark");
}
document.addEventListener("DOMContentLoaded", () => {
  bootTheme();
  if (typeof updateCartCount === "function") updateCartCount();
  if (typeof renderCartPage === "function") renderCartPage();
});