// Base URL for Express API.
// When deployed, replace the empty string with your Render/Railway URL.
// e.g. "https://shoeta-api.onrender.com"
(function () {
  const loc = window.location;
  const isLocal =
    loc.hostname === "localhost" ||
    loc.hostname === "127.0.0.1" ||
    loc.protocol === "file:";
  window.SHOETA_API_BASE = isLocal ? "http://localhost:5000" : "https://your-render-app.onrender.com";
})();
