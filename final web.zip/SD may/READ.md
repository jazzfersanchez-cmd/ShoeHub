# SHOE-TA — Sneaker E-Commerce (School Project)

A full-stack sneaker store with customer storefront, admin portal, and staff portal.

---

## Project Structure

```
SD may/
├── client/          Customer-facing pages (shop, cart, checkout, orders, profile…)
│   └── js/          Shared JS (Supabase client, cart, auth, products)
├── admin/           Admin portal (dashboard, orders, users, analytics, products)
├── staff/           Staff portal (dashboard, product upload)
├── server/          Node.js + Express API (port 5000)
│   ├── routes/      API route handlers
│   └── middleware/  requireAdmin JWT middleware
└── order.html       Root redirect → client/orders.html
```

---

## Quick Start

### 1. Set up the database
Open Supabase SQL Editor and run `client/supabase_schema.sql` to create all tables.

### 2. Configure the server
Edit `server/.env`:
```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key   ← from Supabase Settings → API
ADMIN_EMAILS=your@email.com
```

### 3. Start the server
```bash
cd server
npm install
npm start
# Server runs at http://localhost:5000
```

### 4. Open the app
Open `client/index.html` in your browser (or serve with Live Server).

---

## Features

### Customer
- Browse products with search, category filter, and sort
- Product detail page
- Size selector, Add to Cart, Compare (up to 3 products)
- Checkout with payment method selection (COD, GCash, PayMaya, Card)
- Stock validation at checkout — prevents ordering out-of-stock items
- Order history with status tracking
- Cancel pending/processing orders
- Dark mode

### Admin (`admin/`)
- Dashboard with live KPI stats
- Orders — view all orders, update status
- Users — list all users, change roles (user/staff/admin)
- Analytics — revenue chart, order status breakdown, low-stock alerts
- Products — upload new products to catalog

### Staff (`staff/`)
- Dashboard with store overview and recent orders
- Product upload (staff + admin roles allowed)

### Server API (`/api/...`)
| Endpoint | Description |
|---|---|
| `GET /api/products` | List all products |
| `GET /api/products/:id` | Single product |
| `GET /api/orders` | User's orders (auth required) |
| `POST /api/orders` | Create order (auth required) |
| `PATCH /api/orders/:id/cancel` | Cancel order (auth required) |
| `POST /api/payments/checkout` | Process payment |
| `GET /api/payments/methods` | List payment methods |
| `GET /api/admin/orders` | All orders (admin only) |
| `PATCH /api/admin/orders/:id` | Update order status (admin only) |
| `GET /api/admin/users` | List all users (admin only) |
| `PATCH /api/admin/users/:id/role` | Change user role (admin only) |
| `GET /api/admin/analytics` | Revenue + stats (admin only) |

---

## How to Become Admin

**Step 1** — Register an account at `client/register.html`

**Step 2** — Add your email to `server/.env`:
```
ADMIN_EMAILS=your@email.com
```
This gives access to `client/admin.html` (order management panel).

**Step 3** — Set your role in Supabase SQL Editor:
```sql
UPDATE public.profiles SET role = 'admin' WHERE id = 'your-user-uuid';
```
This gives access to `admin/dashboard.html` (full admin portal).
Your UUID is shown on your profile page or in Supabase → Authentication → Users.

---

## Database Tables

| Table | Purpose |
|---|---|
| `products` | Product catalog |
| `profiles` | User roles (user / staff / admin) |
| `orders` | Customer orders |
| `order_items` | Line items per order |

Run `client/supabase_schema.sql` to create all tables with correct RLS policies.
