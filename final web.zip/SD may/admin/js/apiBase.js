// admin/js/apiBase.js
// Change PROD_API_URL to your Render/Railway URL when you deploy.
(function () {
  const PROD_API_URL = "https://your-render-app.onrender.com";
  const loc = window.location;
  const isLocal =
    loc.hostname === "localhost" ||
    loc.hostname === "127.0.0.1" ||
    loc.protocol === "file:";
  window.SHOETA_API_BASE = isLocal ? "http://localhost:5000" : PROD_API_URL;
})();
